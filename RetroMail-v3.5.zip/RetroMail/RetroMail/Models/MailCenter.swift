import Foundation
import BackgroundTasks
import UserNotifications

/// 全局邮件服务：管理每个账户的 IMAP 连接、文件夹和未读数。
@MainActor
final class MailCenter: ObservableObject {
    static let shared = MailCenter()

    @Published var folders: [UUID: [MailFolder]] = [:]
    @Published var unread: [String: Int] = [:]
    @Published var folderErrors: [UUID: String] = [:]
    @Published var loadingAccounts: Set<UUID> = []
    /// 上次检查邮件的时间（工具栏显示“已更新 …”）
    @Published var lastUpdated: Date?
    /// 底部的操作提示（“已移到归档 · 撤销”）
    @Published var toast: MailToast?
    /// 点通知后要打开的邮件
    @Published var openRequest: OpenRequest?
    /// 点跟进提醒后要打开的事项
    @Published var openFollowUp: String?
    var liveTasks: [Task<Void, Never>] = []
    var idleConnections: [UUID: IMAPConnection] = [:]

    /// 每个账户三条独立连接，互不排队：
    /// - interactive：打开邮件、标记、移动、删除（用户正在等的操作）
    /// - sync：刷新邮件列表、加载更早的邮件、搜索
    /// - background：未读数、会话关联查找、预取正文
    enum Lane: String, CaseIterable {
        case interactive, sync, background
    }

    private var clients: [String: IMAPClient] = [:]

    private init() {}

    func client(for a: MailAccount, _ lane: Lane = .interactive) -> IMAPClient {
        let key = a.id.uuidString + "|" + lane.rawValue
        if let c = clients[key] { return c }
        let c = IMAPClient(config: a.imapConfig())
        clients[key] = c
        return c
    }

    /// 账户设置改变后丢弃旧连接。
    func reset(_ id: UUID) {
        for lane in Lane.allCases {
            if let old = clients.removeValue(forKey: id.uuidString + "|" + lane.rawValue) {
                Task { await old.shutdown() }
            }
        }
        folders[id] = nil
        folderErrors[id] = nil
    }

    func unreadKey(_ id: UUID, _ path: String) -> String { id.uuidString + "|" + path }

    func folder(_ a: MailAccount, role: FolderRole) -> MailFolder? {
        folders[a.id]?.first { $0.role == role && $0.selectable }
    }

    func loadAll() async {
        for a in AccountStore.shared.accounts {
            if folders[a.id] == nil, let cached = DiskCache.loadFolders(account: a.id) {
                folders[a.id] = cached
            }
        }
        await withTaskGroup(of: Void.self) { group in
            for a in AccountStore.shared.accounts {
                group.addTask { await self.loadFolders(a) }
            }
        }
        lastUpdated = Date()
    }

    func loadFolders(_ a: MailAccount) async {
        loadingAccounts.insert(a.id)
        defer { loadingAccounts.remove(a.id) }
        do {
            let list = try await client(for: a, .sync).perform { try await $0.listFolders() }
            let sorted = MailFolder.sorted(list)
            folders[a.id] = sorted
            folderErrors[a.id] = nil
            DiskCache.saveFolders(sorted, account: a.id)
            // 未读数在后台连接上慢慢查，同时预先连好“交互”连接，打开邮件时不用再握手。
            Task { await self.refreshUnread(a) }
            Task { await self.client(for: a, .interactive).warm() }
        } catch {
            folderErrors[a.id] = error.localizedDescription
        }
    }

    // MARK: - 文件夹管理

    /// 账户的层级分隔符（新建子文件夹时用）。
    func delimiter(_ a: MailAccount) -> String {
        folders[a.id]?.compactMap(\.delimiter).first { !$0.isEmpty } ?? "/"
    }

    /// 由上级文件夹和显示名拼出服务器上的路径（名称转成 IMAP UTF-7）。
    func path(for name: String, parent: MailFolder?, account a: MailAccount) -> String {
        let leaf = IMAPUTF7.encode(name.trimmingCharacters(in: .whitespacesAndNewlines))
        guard let p = parent else { return leaf }
        return p.path + delimiter(a) + leaf
    }

    func createFolder(_ a: MailAccount, path: String) async throws {
        try await client(for: a, .interactive).perform { try await $0.createFolder(path) }
        await loadFolders(a)
    }

    func renameFolder(_ a: MailAccount, from old: String, to new: String) async throws {
        try await client(for: a, .interactive).perform { try await $0.renameFolder(old, to: new) }
        // 其他连接可能还选着旧文件夹，重连一下更稳妥
        for lane in [Lane.sync, .background] {
            if let c = clients.removeValue(forKey: a.id.uuidString + "|" + lane.rawValue) {
                Task { await c.shutdown() }
            }
        }
        AppSettings.shared.moveFolderIcon(account: a.id, from: old, to: new)
        await loadFolders(a)
    }

    func deleteFolder(_ a: MailAccount, path: String) async throws {
        for lane in [Lane.sync, .background] {
            if let c = clients.removeValue(forKey: a.id.uuidString + "|" + lane.rawValue) {
                Task { await c.shutdown() }
            }
        }
        try await client(for: a, .interactive).perform { try await $0.deleteFolder(path) }
        AppSettings.shared.setFolderIcon(nil, account: a.id, path: path)
        unread[unreadKey(a.id, path)] = nil
        await loadFolders(a)
    }

    func refreshUnread(_ a: MailAccount, paths: [String]? = nil) async {
        guard let list = folders[a.id] else { return }
        let c = client(for: a, .background)
        let targets = list.filter { f in
            if let p = paths { return p.contains(f.path) }
            return f.selectable && ![.sent, .drafts, .trash].contains(f.role)
        }
        // 收件箱优先
        for f in targets.sorted(by: { $0.role.order < $1.role.order }) {
            let p = f.path
            if let st = try? await c.perform({ try await $0.status(p) }) {
                unread[unreadKey(a.id, p)] = st.unseen
                if f.role == .inbox, st.uidNext > 0 {
                    BackgroundRefresh.noteSeen(account: a.id, nextUID: st.uidNext)
                }
            }
        }
    }

    func adjustUnread(_ a: MailAccount, _ path: String, by delta: Int) {
        let k = unreadKey(a.id, path)
        unread[k] = max(0, (unread[k] ?? 0) + delta)
    }

    // MARK: - 会话：跨文件夹查找相关邮件

    /// 在“已发送”“收件箱”等文件夹里查找属于同一会话的邮件（Outlook 会话视图的做法）。
    func relatedMessages(_ a: MailAccount, conversation: Conversation, currentFolder: String) async -> [(folder: String, summary: MessageSummary)] {
        if folders[a.id] == nil { await loadFolders(a) }
        let core = Threading.core(conversation.latest.subject)
        guard !core.isEmpty else { return [] }
        var targets: [String] = []
        for role in [FolderRole.inbox, .sent] {
            if let f = folder(a, role: role), f.path != currentFolder { targets.append(f.path) }
        }
        let c = client(for: a, .background)
        var out: [(folder: String, summary: MessageSummary)] = []
        for path in targets {
            guard let found = try? await c.perform({ try await $0.searchSubject(path, subject: core, limit: 30) }) else { continue }
            for m in found where conversation.messages.contains(where: { Threading.related($0, m) }) {
                out.append((path, m))
            }
        }
        return out
    }

    // MARK: - 发信 / 草稿

    func send(_ mail: OutgoingMail, account a: MailAccount,
              answered: (folder: String, uid: Int)?, removeDraft: (folder: String, uid: Int)?) async throws {
        if folders[a.id] == nil { await loadFolders(a) }
        let wire = await Task.detached { MIMEBuilder.build(mail, includeBcc: false) }.value
        let smtp = SMTPClient(config: a.smtpConfig())
        try await smtp.send(wire, from: a.email, to: mail.allRecipients)

        let c = client(for: a)
        if a.saveToSent, let sent = folder(a, role: .sent) {
            let copy = await Task.detached { MIMEBuilder.build(mail, includeBcc: true) }.value
            let path = sent.path
            _ = try? await c.perform { try await $0.append(path, message: copy, flags: "\\Seen") }
        }
        if let ref = answered {
            _ = try? await c.perform { try await $0.store(ref.folder, uids: [ref.uid], flag: "\\Answered", add: true) }
        }
        if let ref = removeDraft {
            _ = try? await c.perform { try await $0.delete(ref.folder, uids: [ref.uid], trash: nil) }
        }
    }

    func saveDraft(_ mail: OutgoingMail, account a: MailAccount, replacing: (folder: String, uid: Int)?) async throws {
        if folders[a.id] == nil { await loadFolders(a) }
        guard let drafts = folder(a, role: .drafts) else {
            throw MailError.protocolError(tr("没有找到“草稿箱”文件夹。", "No Drafts folder was found."))
        }
        let data = await Task.detached { MIMEBuilder.build(mail, includeBcc: true) }.value
        let path = drafts.path
        let c = client(for: a)
        try await c.perform { try await $0.append(path, message: data, flags: "\\Draft \\Seen") }
        if let ref = replacing {
            _ = try? await c.perform { try await $0.delete(ref.folder, uids: [ref.uid], trash: nil) }
        }
    }
}

// MARK: - 后台检查新邮件 + 本地通知

enum BackgroundRefresh {
    static let taskID = "com.raynec.retromail.refresh"
    static let enabledKey = "notifyNewMail"

    static var enabled: Bool { UserDefaults.standard.bool(forKey: enabledKey) }

    static func schedule() {
        guard enabled else { return }
        let req = BGAppRefreshTaskRequest(identifier: taskID)
        req.earliestBeginDate = Date(timeIntervalSinceNow: 5 * 60)
        try? BGTaskScheduler.shared.submit(req)
    }

    private static func key(_ id: UUID) -> String { "nextUID.\(id.uuidString)" }

    static func lastUID(_ id: UUID) -> Int { UserDefaults.standard.integer(forKey: key(id)) }
    static func setLastUID(_ id: UUID, _ v: Int) { UserDefaults.standard.set(v, forKey: key(id)) }

    /// 前台已经看到的邮件不再通知。
    static func noteSeen(account: UUID, nextUID: Int) {
        let k = key(account)
        if nextUID > UserDefaults.standard.integer(forKey: k) {
            UserDefaults.standard.set(nextUID, forKey: k)
        }
    }

    static func run() async {
        schedule()
        guard enabled else { return }
        let accounts = AccountStore.loadFromDisk()
        for a in accounts {
            let client = IMAPClient(config: a.imapConfig())
            do {
                let last = UserDefaults.standard.integer(forKey: key(a.id))
                let st = try await client.perform { try await $0.status("INBOX") }
                if last > 0, st.uidNext > last {
                    let fresh = try await client.perform { try await $0.fetchSince("INBOX", uid: last) }
                    let unseen = fresh.filter { !$0.seen }
                    if !unseen.isEmpty {
                        await MailNotifier.post(unseen, account: a, folder: "INBOX", client: client)
                    }
                }
                if MailPrefs.badge {
                    await MailNotifier.setBadge(st.unseen)
                }
                if st.uidNext > 0 { UserDefaults.standard.set(st.uidNext, forKey: key(a.id)) }
            } catch {
                // 后台失败静默忽略，下次再试。
            }
            await client.shutdown()
        }
    }

    private static func notify(_ a: MailAccount, _ msgs: [MessageSummary], multiAccount: Bool) async {
        guard !msgs.isEmpty else { return }
        let center = UNUserNotificationCenter.current()
        for m in msgs.prefix(5) {
            let c = UNMutableNotificationContent()
            c.title = m.from?.display ?? a.email
            if multiAccount { c.subtitle = a.email }
            c.body = m.subject.isEmpty ? tr("（无主题）", "(No subject)") : m.subject
            c.sound = .default
            c.threadIdentifier = a.id.uuidString
            let req = UNNotificationRequest(identifier: "\(a.id.uuidString)-\(m.uid)", content: c, trigger: nil)
            try? await center.add(req)
        }
        if msgs.count > 5 {
            let c = UNMutableNotificationContent()
            c.title = "RetroMail"
            c.body = tr("\(a.email) 还有 \(msgs.count - 5) 封新邮件", "\(msgs.count - 5) more new messages for \(a.email)")
            c.threadIdentifier = a.id.uuidString
            try? await center.add(UNNotificationRequest(identifier: "\(a.id.uuidString)-more", content: c, trigger: nil))
        }
    }

    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }
}
